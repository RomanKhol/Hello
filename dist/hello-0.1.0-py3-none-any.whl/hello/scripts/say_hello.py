def main():
    from colorama import Fore, Style
    print(Fore.RED + "Hello!" + Style.RESET_ALL)

if __name__ == '__main__':
    main()
